(function(){
/* PlayHub 어드민 패널 — 북마크 버튼으로 내 사이트 아무 페이지(허브 · 게임) 위에 띄운다 */
if (window.__adm){ window.__adm.toggle(); return; }
const geval = eval;
const MPx = () => window.MP || null;
const hasFB = () => !!(window.firebase && firebase.apps && firebase.apps.length);
const host = document.createElement('div');
host.id = '__admHost';
host.style.cssText = 'position:fixed;right:12px;top:12px;z-index:2147483647;';
document.body.appendChild(host);
const sh = host.attachShadow({ mode:'open' });
sh.innerHTML = `<style>
*{box-sizing:border-box;margin:0;padding:0;font-family:system-ui,'Noto Sans KR',sans-serif}
.p{width:min(360px,92vw);max-height:84vh;display:flex;flex-direction:column;background:#12162b;color:#eef1ff;border:1px solid #333c66;border-radius:14px;box-shadow:0 20px 50px #000b;font-size:13px}
.hd{display:flex;align-items:center;gap:8px;padding:10px 12px;border-bottom:1px solid #262e52;cursor:move}
.hd b{flex:1;font-size:14px}
.tabs{display:flex;gap:4px;padding:8px 10px 0}
.tab{flex:1;padding:7px;border-radius:8px 8px 0 0;background:#1b2140;color:#9aa3c7;font-weight:800;border:0;cursor:pointer}
.tab.on{background:#5b7cff;color:#fff}
.bd{overflow-y:auto;padding:10px 12px 14px}
h3{font-size:11.5px;color:#9aa3c7;margin:12px 0 6px;letter-spacing:.04em}
h3:first-child{margin-top:2px}
button{border:0;border-radius:8px;padding:7px 10px;margin:2px;background:#232a4d;color:#fff;font-weight:700;font-size:12px;cursor:pointer}
button.g{background:#2cbf7a;color:#04140c} button.b{background:#5b7cff} button.r{background:#d6304a} button.on{background:#5b7cff}
input,select{background:#0b0d1a;color:#fff;border:1px solid #333c66;border-radius:7px;padding:6px 8px;font-size:12px}
.row{display:flex;flex-wrap:wrap;align-items:center;gap:4px;margin:4px 0}
.hint{font-size:11px;color:#7d86ad;line-height:1.5;margin-top:4px}
.v{display:flex;align-items:center;gap:4px;padding:3px 0;border-bottom:1px solid #1f2547}
.v code{flex:1;font-size:11px;color:#ffc44d;word-break:break-all}
.v input[type=number],.v input.t{width:96px}
.v label{font-size:11px;white-space:nowrap}
.toast{position:absolute;left:50%;bottom:-36px;transform:translateX(-50%);background:#000d;padding:6px 12px;border-radius:14px;font-size:12px;font-weight:800;opacity:0;transition:.2s;white-space:nowrap;pointer-events:none}
.toast.on{opacity:1}
</style>
<div class="p">
 <div class="hd"><b>⚡ 어드민</b><button data-a="min">—</button><button data-a="close">✕</button></div>
 <div class="tabs"><button class="tab on" data-t="acc">계정</button><button class="tab" data-t="game">게임 치트</button><button class="tab" data-t="ls">저장값</button></div>
 <div class="bd"></div>
</div><div class="toast"></div>`;
const P = sh.querySelector('.p'), BD = sh.querySelector('.bd'), TO = sh.querySelector('.toast');
const esc = s => String(s).replace(/[&<>"]/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
function toast(m){ TO.textContent = m; TO.classList.add('on'); clearTimeout(toast.t); toast.t = setTimeout(()=>TO.classList.remove('on'), 1800); }
let tab = 'acc', hidden = false;
window.__adm = { toggle(){ hidden = !hidden; host.style.display = hidden ? 'none' : ''; } };

/* 패널 끌어서 옮기기 */
(function(){ const hd = sh.querySelector('.hd'); let d = null;
  hd.addEventListener('pointerdown', e=>{ if (e.target.tagName === 'BUTTON') return; const r = host.getBoundingClientRect(); d = { x:e.clientX - r.left, y:e.clientY - r.top }; hd.setPointerCapture(e.pointerId); });
  hd.addEventListener('pointermove', e=>{ if (!d) return; host.style.left = (e.clientX - d.x) + 'px'; host.style.top = (e.clientY - d.y) + 'px'; host.style.right = 'auto'; });
  hd.addEventListener('pointerup', ()=>{ d = null; });
})();
/* 패널 안에서 누른 키 · 클릭이 게임으로 새지 않게 */
['keydown','keyup','keypress','pointerdown','mousedown','touchstart','wheel','click'].forEach(t=>host.addEventListener(t, e=>e.stopPropagation()));

sh.querySelector('[data-a="close"]').onclick = ()=> window.__adm.toggle();
sh.querySelector('[data-a="min"]').onclick = ()=>{ const t = sh.querySelector('.tabs'); const on = BD.style.display !== 'none'; BD.style.display = on ? 'none' : ''; t.style.display = on ? 'none' : ''; };
sh.querySelectorAll('.tab').forEach(b=>b.onclick = ()=>{ tab = b.dataset.t; sh.querySelectorAll('.tab').forEach(x=>x.classList.toggle('on', x === b)); render(); });

/* ================= 계정 ================= */
const need = lv => Math.round(500 * Math.pow(1.18, Math.max(0, lv - 1)));
const xpForLevel = lv => { let s = 0; for (let i = 1; i < lv; i++) s += need(i); return Math.ceil(s * 1.000001); };
const BOARDS = [
 ['level','desc','계정 레벨 (XP)'],['aura_best','desc','아우라 배틀 최고 등급'],['jumpmap','asc','⏱ 스카이 점프맵 완주 (ms)'],['jumpmap_cp','desc','스카이 점프맵 체크포인트'],
 ['rainbow100','desc','레인보우 100 레벨'],['wordchain_wins','desc','끝말잇기 우승'],['garden_tier','desc','그로우 가든 최고 등급 (0~11)'],['garden_value','desc','그로우 가든 최고 작물'],
 ['mmo_lv','desc','에테리아 레벨'],['mmo_boss','desc','기사왕 피해량'],['battlegrounds_kills','desc','가장 강한 전장 처치'],['admintower','asc','⏱ 어드민 타워 (ms)'],
 ['protower','asc','⏱ 고수 타워 (ms)'],['protower_floor','desc','고수 타워 최고층 (16 = 정복)'],['nightfall','desc','나이트폴 (웨이브×10000+킬)'],['forest_level','desc','포레스트 레벨'],
 ['redline_rr','desc','REDLINE RR'],['redline_kills','desc','REDLINE 처치'],['exit8_best','asc','⏱ 8번 출구 (ms)'],['backrooms','asc','⏱ 백룸 (ms)'],
 ['ambo_wins','desc','암보 승리'],['isle_best','asc','⏱ 바람의 섬 (초)'],['fruit_best','desc','프루티 팝 점수'],['hotel_best','desc','심야 호텔 최고 문 (100 = 탈출)'],
 ['mnq_best','desc','마네킹 백화점 최고 밤'],['jamboree_wins','desc','잼버리 우승'] ];
const shards = () => parseInt(localStorage.getItem('shard_balance') || '0', 10) || 0;
function syncHub(){ try { geval('typeof syncShardFromStorage==="function"&&syncShardFromStorage()'); } catch(e){} try { geval('typeof refreshLevelUI==="function"&&refreshLevelUI()'); } catch(e){} }
function setShards(n){ localStorage.setItem('shard_balance', String(Math.max(0, Math.floor(n)))); syncHub(); render(); toast('샤드 ' + Math.floor(n).toLocaleString()); }
function unlockAll(){
  const M = MPx(); if (!M) return toast('허브나 게임 페이지에서 눌러 주세요');
  const ids = new Set(), sec = new Set(['ditto']);
  const take = it => { if (!it) return; if (it.id) ids.add(it.id); if (it.secret) sec.add(it.secret); };
  (M.AVATAR_CATALOG||[]).forEach(take); (M.AVATAR_FACES||[]).forEach(take); (M.EMOTES||[]).forEach(take);
  const pal = M.AVATAR_PALETTE || {}; Object.keys(pal).forEach(k=>(pal[k]||[]).forEach(take));
  ids.forEach(id=>{ try { M.addOwnedItem(id); } catch(e){} });
  sec.forEach(s=>{ try { M.unlockSecret(s); } catch(e){} });
  toast('아이템 ' + ids.size + '개 · 시크릿 ' + sec.size + '개 해금');
}
function setXP(target){
  const M = MPx(); if (!M || !M.uid) return toast('로그인된 허브 · 게임 페이지에서 눌러 주세요');
  target = Math.max(0, Math.floor(target));
  const cur = M.getLevel().total;
  if (target >= cur){ M.addXP(target - cur, ()=>{ try { M.claimLevelRewards(); } catch(e){} syncHub(); render(); toast('LV ' + M.getLevel().level); }); return; }
  const lv = M.levelFromXP(target).level;
  localStorage.setItem('mp_xp', String(target));
  firebase.database().ref('playhub_mp/users/' + M.uid).update({ xp:target, level:lv })
    .then(()=>{ toast('LV ' + lv + ' — 새로고침할게요'); setTimeout(()=>location.reload(), 700); }).catch(e=>toast('실패: ' + (e.code||e)));
}
function accHTML(){
  const M = MPx(), u = M && M.currentUser && M.currentUser();
  const L = M && M.getLevel ? M.getLevel() : null;
  return `<h3>상태</h3><div class="hint">${M ? (u ? (u.isAnonymous ? '게스트로 접속 중 (로그인하면 계정에 저장돼요)' : '로그인: ' + esc(u.email||'')) : '접속 중…') : '⚠ 이 페이지엔 multiplayer.js 가 없어요 — 허브에서 눌러 주세요'}</div>
  <h3>🔷 샤드 — 지금 ${shards().toLocaleString()}</h3>
  <div class="row"><input id="shIn" type="number" placeholder="양" style="width:110px"><button class="b" data-x="shSet">설정</button><button data-x="shAdd">+10,000</button><button data-x="shMax">99,999,999</button></div>
  <div class="row"><button data-x="shPkg">샤드 상점 패키지 전부 받기 가능</button></div>
  <h3>🎒 아바타</h3><div class="row"><button class="g" data-x="all">모든 아이템 · 얼굴 · 이모트 · 시크릿 해금</button></div>
  <h3>⭐ 계정 레벨 — ${L ? 'LV ' + L.level + ' · ' + L.total.toLocaleString() + ' XP' : '-'}</h3>
  <div class="row"><input id="lvIn" type="number" min="1" max="200" placeholder="레벨" style="width:80px"><button class="b" data-x="lvSet">설정</button><button data-x="lvUp">+1</button><button data-x="lvMax">200</button></div>
  <h3>🏆 랭킹</h3>
  <div class="row"><select id="lbCat" style="flex:1">${BOARDS.map((b,i)=>'<option value="'+i+'">'+esc(b[2])+'</option>').join('')}</select></div>
  <div class="row">내 기록: <b id="lbMine">-</b></div>
  <div class="row"><input id="lbIn" type="number" placeholder="점수" style="width:110px"><button class="b" data-x="lbSet">올리기</button><button class="r" data-x="lbDel">삭제</button></div>
  <div class="hint">랭킹은 모두에게 보여요. 원래 기록보다 좋을 때만 바뀌니까 낮추려면 먼저 삭제.</div>`;
}
function loadMine(){
  const M = MPx(), el = sh.getElementById('lbMine'); if (!el) return;
  if (!M || !M.fetchMyScore){ el.textContent = '-'; return; }
  const b = BOARDS[+sh.getElementById('lbCat').value]; el.textContent = '…';
  M.fetchMyScore(b[0], v=>{ el.textContent = v && v.score != null ? Number(v.score).toLocaleString() : '기록 없음'; });
}
const ACT = {
  shSet: ()=>{ const v = +sh.getElementById('shIn').value; if (isFinite(v)) setShards(v); },
  shAdd: ()=> setShards(shards() + 10000),
  shMax: ()=> setShards(99999999),
  shPkg: ()=>{ localStorage.setItem('shard_claimed', '[]'); localStorage.setItem('total_play_seconds', String(1300*60)); toast('새로고침하면 상점에서 다 받을 수 있어요'); },
  all: unlockAll,
  lvSet: ()=>{ const v = Math.min(200, Math.max(1, Math.floor(+sh.getElementById('lvIn').value || 1))); setXP(xpForLevel(v)); },
  lvUp: ()=>{ const M = MPx(); if (M) setXP(xpForLevel(Math.min(200, M.getLevel().level + 1))); },
  lvMax: ()=> setXP(xpForLevel(200)),
  lbSet: ()=>{ const M = MPx(); if (!M || !M.uid) return toast('로그인된 페이지에서'); const s = +sh.getElementById('lbIn').value; const b = BOARDS[+sh.getElementById('lbCat').value];
    M.submitScore(b[0], s, b[1], b[0] === 'level' ? { level:M.levelFromXP(s).level } : {}, ok=>{ toast(ok ? '올림!' : '기존 기록이 더 좋아요 — 먼저 삭제'); loadMine(); }); },
  lbDel: ()=>{ const M = MPx(); if (!M || !M.uid || !hasFB()) return toast('로그인된 페이지에서'); const b = BOARDS[+sh.getElementById('lbCat').value]; if (!confirm(b[2] + ' 내 기록 삭제?')) return;
    firebase.database().ref('playhub_mp/leaderboard/' + b[0] + '/' + M.uid).remove().then(()=>{ toast('삭제'); loadMine(); }).catch(e=>toast('실패: ' + (e.code||e))); }
};

/* ================= 게임 치트 ================= */
/* 속도: 지금 시점부터 시간을 n배로 */
const realNow = performance.now.bind(performance), realRAF = window.requestAnimationFrame.bind(window);
let speed = 1, baseR = realNow(), baseF = baseR;
const fakeNow = () => baseF + (realNow() - baseR) * speed;
performance.now = fakeNow;
window.requestAnimationFrame = cb => realRAF(()=>{ try { flyStep(); } catch(e){} cb(fakeNow()); });
function setSpeed(n){ baseF = fakeNow(); baseR = realNow(); speed = n; }

/* 게임이 만든 전역 변수 전부: window 에 붙은 것 + 스크립트에 let/var 로 선언된 것 */
function globalVars(){
  const fr = document.createElement('iframe'); fr.style.display = 'none'; document.body.appendChild(fr);
  const base = new Set(Object.getOwnPropertyNames(fr.contentWindow)); fr.remove();
  const out = [];
  Object.getOwnPropertyNames(window).forEach(k=>{ if (base.has(k) || /^(MP|firebase|THREE|__adm)$/.test(k) || k.indexOf('__') === 0) return; out.push({ name:k, get:()=>window[k], set:x=>{ window[k] = x; } }); });
  const names = new Set();
  document.querySelectorAll('script:not([src])').forEach(s=>{ const re = /(?:^|[;{}\n])\s*(?:let|var|const)\s+([A-Za-z_$][\w$]*(?:\s*=[^,;]*)?(?:\s*,\s*[A-Za-z_$][\w$]*(?:\s*=[^,;]*)?)*)/g; let m;
    while ((m = re.exec(s.textContent))) m[1].split(',').forEach(p=>{ const nm = p.trim().split(/[\s=]/)[0]; if (nm) names.add(nm); }); });
  names.forEach(nm=>{ if (nm in window) return; try { if (geval('typeof ' + nm) === 'undefined') return; } catch(e){ return; }
    out.push({ name:nm, get:()=>geval(nm), set:x=>geval(nm + '=' + JSON.stringify(x)) }); });
  return out;
}

const WANT = /coin|money|gold|cash|gem|shard|diamond|xp|exp|level|lv|hp|health|score|energy|ammo|life|lives|stamina|mana|point|credit|speed|jump|grav|dmg|damage|power|time|wave|kill|stage|floor|cp|checkpoint/i;
const OBJ = /player|stat|save|data|state|game|me|hero|char|inv|wallet|stats/i;
let found = [];
const frozen = new Map();
setInterval(()=>{ frozen.forEach((v, c)=>{ try { c.set(v); } catch(e){} }); }, 100);
function scan(){
  const out = [], seen = new Set();
  const addObj = (label, o, depth) => {
    if (!o || typeof o !== 'object' || o instanceof Node || seen.has(o) || o.isObject3D) return; seen.add(o);
    let n = 0;
    for (const k in o){ if (n++ > 400) break; let v; try { v = o[k]; } catch(e){ continue; }
      if (typeof v === 'number' && WANT.test(k)) out.push({ label:label + '.' + k, get:()=>o[k], set:x=>{ o[k] = x; } });
      else if (typeof v === 'boolean' && /fly|god|noclip|invinc|dead|lock/i.test(k)) out.push({ label:label + '.' + k, bool:true, get:()=>o[k], set:x=>{ o[k] = x; } });
      else if (depth < 2 && v && typeof v === 'object' && !Array.isArray(v) && OBJ.test(k)) addObj(label + '.' + k, v, depth + 1);
    }
  };
  globalVars().forEach(g=>{
    let v; try { v = g.get(); } catch(e){ return; }
    if (typeof v === 'number' && WANT.test(g.name)) out.push({ label:g.name, get:g.get, set:g.set });
    else if (typeof v === 'boolean' && /fly|god|noclip|invinc/i.test(g.name)) out.push({ label:g.name, bool:true, get:g.get, set:g.set });
    else if (v && typeof v === 'object' && !(v instanceof Node) && !Array.isArray(v)) addObj(g.name, v, OBJ.test(g.name) ? 0 : 1);
  });
  found = out.slice(0, 150);
}

/* ---------- 플라이 · 노클립 ----------
   three.js 게임에서 플레이어(또는 카메라)를 찾아, 화면에 그리기 직전마다 내가 정한 위치로 옮긴다.
   게임의 중력 · 충돌은 무시되니까 벽도 통과한다. */
const FLY = { on:false, target:null, cam:null, pos:null, speed:14, keys:{}, vels:[], cands:[], sel:0 };
const PLAYERISH = /player|me$|^me|hero|char|avatar|body|rig|local|self|you/i;
addEventListener('keydown', e=>{ FLY.keys[e.code] = true; if (e.code === 'F8'){ e.preventDefault(); flyToggle(); } }, true);
addEventListener('keyup', e=>{ FLY.keys[e.code] = false; }, true);
addEventListener('blur', ()=>{ FLY.keys = {}; });
function rootOf(o){ while (o.parent) o = o.parent; return o; }
function findThree(){
  const cams = [], objs = [], scenes = new Set(), seen = new Set();
  const visit = (name, v, depth) => {
    if (!v || typeof v !== 'object' || seen.has(v) || v instanceof Node) return; seen.add(v);
    if (v.isScene){ scenes.add(v); return; }
    if (v.isCamera){ cams.push({ name, o:v }); return; }
    if (v.isObject3D){ objs.push({ name, o:v }); return; }
    if (!Array.isArray(v) && typeof v.x === 'number' && typeof v.y === 'number' && typeof v.z === 'number' && PLAYERISH.test(name)){ objs.push({ name, o:v, xyz:true }); }
    if (depth < 1 && !Array.isArray(v)){ let n = 0; for (const k in v){ if (n++ > 200) break; let x; try { x = v[k]; } catch(e){ continue; }
      if (x && typeof x === 'object' && (x.isObject3D || ((PLAYERISH.test(k) || /pos/i.test(k)) && typeof x.x === 'number' && typeof x.y === 'number'))) visit(name + '.' + k, x, depth + 1); } }
  };
  globalVars().forEach(g=>{ let v; try { v = g.get(); } catch(e){ return; } visit(g.name, v, 0); });
  cams.concat(objs).forEach(c=>{ if (c.o.isObject3D){ const r = rootOf(c.o); if (r.isScene) scenes.add(r); } });
  scenes.forEach(hookScene);
  const cands = [];
  objs.filter(c=>PLAYERISH.test(c.name) && !(c.o.isObject3D && c.o.isMesh && !c.o.children.length)).forEach(c=>cands.push({ label:'🧍 ' + c.name + (c.xyz ? ' (좌표)' : ''), o:c.o, xyz:c.xyz }));
  cams.forEach(c=>{ let r = c.o; while (r.parent && !r.parent.isScene) r = r.parent; if (r !== c.o) cands.push({ label:'🧍 ' + c.name + ' 를 들고 있는 몸', o:r }); });
  cams.forEach(c=>cands.push({ label:'📷 ' + c.name + ' (카메라 · 자유 시점)', o:c.o }));
  objs.filter(c=>!PLAYERISH.test(c.name) && c.o.isObject3D).slice(0, 15).forEach(c=>cands.push({ label:'📦 ' + c.name, o:c.o }));
  FLY.cands = cands; FLY.cam = cams[0] ? cams[0].o : null;
  if (FLY.sel >= cands.length) FLY.sel = 0;
  return cands.length;
}
function hookScene(s){
  if (s.__admFly) return; s.__admFly = true;
  const orig = s.onBeforeRender;
  s.onBeforeRender = function(){ try { if (FLY.on) applyPos(); } catch(e){} return orig && orig.apply(this, arguments); };
}
function findVels(){
  const out = [], VN = /^(vy|velY|yVel|vY|velocityY|fallSpeed|yv|ySpeed)$/i;
  const fromObj = o => { if (!o || typeof o !== 'object') return;
    for (const k of ['vy','velY','yVel','vY','velocityY','fallSpeed','ySpeed']) if (typeof o[k] === 'number') out.push(()=>{ o[k] = 0; });
    for (const k of ['velocity','vel','v']){ const x = o[k]; if (x && typeof x === 'object' && typeof x.y === 'number') out.push(()=>{ x.x = 0; x.y = 0; if (typeof x.z === 'number') x.z = 0; }); } };
  globalVars().forEach(g=>{ let v; try { v = g.get(); } catch(e){ return; }
    if (typeof v === 'number' && VN.test(g.name)) out.push(()=>g.set(0));
    else if (v && typeof v === 'object' && !(v instanceof Node)){ if (/vel/i.test(g.name) && typeof v.y === 'number') out.push(()=>{ v.x = 0; v.y = 0; if (typeof v.z === 'number') v.z = 0; }); else if (PLAYERISH.test(g.name)) fromObj(v); } });
  if (FLY.target){ fromObj(FLY.target); fromObj(FLY.target.userData); }
  return out;
}
function curPos(t){ const T = window.THREE; if (t.isObject3D){ const v = new T.Vector3(); t.getWorldPosition(v); return v; } return new T.Vector3(t.x, t.y, t.z); }
function applyPos(){
  const t = FLY.target; if (!t || !FLY.pos) return;
  if (t.isObject3D){
    if (t.parent && !t.parent.isScene){ const p = FLY.pos.clone(); t.parent.updateMatrixWorld(true); t.parent.worldToLocal(p); t.position.copy(p); }
    else t.position.copy(FLY.pos);
    t.updateMatrixWorld(true);
    if (FLY.cam && FLY.cam !== t) FLY.cam.updateMatrixWorld(true);
  } else { t.x = FLY.pos.x; t.y = FLY.pos.y; t.z = FLY.pos.z; }
  FLY.vels.forEach(z=>{ try { z(); } catch(e){} });
}
let flyLast = realNow();
function flyStep(){
  const now = realNow(), dt = Math.min(.1, (now - flyLast) / 1000); flyLast = now;
  if (!FLY.on || !FLY.target || !window.THREE) return;
  const T = window.THREE, K = FLY.keys;
  if (document.activeElement && /INPUT|TEXTAREA/.test(document.activeElement.tagName)){ applyPos(); return; }
  const fwd = new T.Vector3(0, 0, -1);
  if (FLY.cam) FLY.cam.getWorldDirection(fwd);
  fwd.y = 0; if (fwd.lengthSq() < 1e-6) fwd.set(0, 0, -1); fwd.normalize();
  const right = new T.Vector3(-fwd.z, 0, fwd.x), mv = new T.Vector3();
  if (K.KeyW || K.ArrowUp) mv.add(fwd); if (K.KeyS || K.ArrowDown) mv.sub(fwd);
  if (K.KeyD || K.ArrowRight) mv.add(right); if (K.KeyA || K.ArrowLeft) mv.sub(right);
  if (K.Space || K.KeyE) mv.y += 1; if (K.ShiftLeft || K.ShiftRight || K.KeyQ) mv.y -= 1;
  if (mv.lengthSq()) FLY.pos.addScaledVector(mv.normalize(), FLY.speed * dt * (K.ControlLeft ? 3 : 1));
  applyPos();
}
function flyToggle(){
  if (!FLY.on){
    if (!window.THREE) return toast('three.js 게임에서만 돼요');
    if (!FLY.cands.length && !findThree()) return toast('플레이어를 못 찾았어요 — 게임을 시작한 뒤 다시');
    const c = FLY.cands[FLY.sel]; FLY.target = c.o; FLY.pos = curPos(c.o); FLY.vels = findVels(); FLY.on = true;
    toast('플라이 ON — ' + c.label.replace(/^\S+ /, '') + ' (F8로 끄기)');
  } else { FLY.on = false; toast('플라이 OFF'); }
  if (tab === 'game') render();
}

/* ---------- 모든 무기 · 아이템 갖기 (자동 탐색) ----------
   게임 안에서 "아이템 목록"(id + 가격/데미지가 있는 배열)과 "가진 것 목록"(owned · unlocked · inventory …)을 찾아서
   목록에 있는 걸 전부 가진 것에 넣는다. 게임 메모리와 저장값(localStorage) 둘 다 바꾼다. */
const OWNN = /own|unlock|bought|purchas|inventor|have|collected|gun|weapon|skin|item/i;
let unlockPlan = null;
function idOf(x){ return x && (x.id != null ? x.id : x.key != null ? x.key : x.name != null ? x.name : null); }
function looksCatalog(arr){ if (!Array.isArray(arr) || arr.length < 3) return false; let ok = 0;
  for (const x of arr.slice(0, 40)) if (x && typeof x === 'object' && idOf(x) != null && ['price','cost','damage','dmg','rarity','rar','fireRate','ammo','mag','unlock','level','gold'].some(k=>k in x)) ok++;
  return ok >= Math.min(arr.length, 40) * .7; }
function scanUnlock(){
  const cats = [], owns = [], seen = new Set();
  const look = (name, v, depth) => {
    if (!v || typeof v !== 'object' || seen.has(v) || v instanceof Node || v.isObject3D) return; seen.add(v);
    if (Array.isArray(v)){
      if (looksCatalog(v)) cats.push({ name, ids:v.map(idOf).filter(x=>x != null) });
      else if (OWNN.test(name) && v.every(x=>typeof x === 'string' || typeof x === 'number')) owns.push({ name, kind:'arr', ref:v });
      return;
    }
    if (v instanceof Set){ if (OWNN.test(name)) owns.push({ name, kind:'set', ref:v }); return; }
    const ks = Object.keys(v);
    if (ks.length >= 3 && looksCatalog(ks.map(k=>Object.assign({ id:k }, v[k] && typeof v[k] === 'object' ? v[k] : {})))) cats.push({ name, ids:ks });
    else if (OWNN.test(name) && ks.length && ks.every(k=>typeof v[k] === 'boolean' || typeof v[k] === 'number')) owns.push({ name, kind:'map', ref:v });
    if (depth < 2) for (const k of ks.slice(0, 300)){ let x; try { x = v[k]; } catch(e){ continue; } if (x && typeof x === 'object') look(name + '.' + k, x, depth + 1); }
  };
  globalVars().forEach(g=>{ let v; try { v = g.get(); } catch(e){ return; } look(g.name, v, 0); });
  for (let i = 0; i < localStorage.length; i++){
    const k = localStorage.key(i); if (/^mp_|shard/.test(k)) continue; const kOk = OWNN.test(k);
    let v; try { v = JSON.parse(localStorage.getItem(k)); } catch(e){ continue; }
    if (Array.isArray(v) && kOk && v.every(x=>typeof x === 'string' || typeof x === 'number')) owns.push({ name:'💾 ' + k, kind:'ls-arr', key:k, ref:v });
    else if (v && typeof v === 'object' && !Array.isArray(v)){ const ks = Object.keys(v);
      if (kOk && ks.length && ks.every(x=>typeof v[x] === 'boolean' || typeof v[x] === 'number')) owns.push({ name:'💾 ' + k, kind:'ls-map', key:k, ref:v });
      else Object.keys(v).forEach(sub=>{ const a = v[sub]; if (Array.isArray(a) && OWNN.test(sub) && a.every(x=>typeof x === 'string' || typeof x === 'number')) owns.push({ name:'💾 ' + k + '.' + sub, kind:'ls-sub', key:k, sub, ref:a, root:v }); }); }
  }
  /* 가진 것 목록마다, 이미 들어있는 id 가 가장 많이 겹치는 아이템 목록을 짝지어 준다 */
  const pairs = [];
  owns.forEach(o=>{
    const have = o.kind.indexOf('map') >= 0 ? Object.keys(o.ref) : Array.from(o.ref).map(String);
    let best = null, score = 0;
    cats.forEach(c=>{ const s = c.ids.filter(id=>have.indexOf(String(id)) >= 0).length; if (s > score){ score = s; best = c; } });
    if (!best && cats.length === 1) best = cats[0];
    if (best) pairs.push({ own:o, cat:best, missing:best.ids.filter(id=>have.indexOf(String(id)) < 0) });
  });
  unlockPlan = { cats, owns, pairs };
}
function doUnlock(){
  if (!unlockPlan) return; let n = 0;
  unlockPlan.pairs.forEach(p=>{
    const o = p.own;
    p.missing.forEach(id=>{
      if (o.kind === 'arr' || o.kind === 'ls-arr' || o.kind === 'ls-sub') o.ref.push(typeof o.ref[0] === 'number' ? +id : id);
      else if (o.kind === 'set') o.ref.add(id);
      else o.ref[id] = (typeof Object.values(o.ref)[0] === 'number') ? 1 : true;
      n++;
    });
    if (o.kind === 'ls-arr' || o.kind === 'ls-map') localStorage.setItem(o.key, JSON.stringify(o.ref));
    if (o.kind === 'ls-sub') localStorage.setItem(o.key, JSON.stringify(o.root));
  });
  toast(n + '개 넣었어요 — 상점 · 무기 화면을 다시 열어 보세요');
  scanUnlock(); render();
}

function gameHTML(){
  const fc = FLY.cands;
  const up = unlockPlan;
  return `<h3>🕊 플라이 · 노클립 (F8)</h3>
  <div class="row"><button class="${FLY.on ? 'on' : 'g'}" data-x="fly">${FLY.on ? '플라이 끄기' : '플라이 켜기'}</button>
   <span style="font-size:11px">속도</span><input id="fsp" type="range" min="3" max="80" value="${FLY.speed}" style="flex:1"></div>
  <div class="row"><select id="ftg" style="flex:1">${fc.length ? fc.map((c,i)=>'<option value="'+i+'"'+(i === FLY.sel ? ' selected' : '')+'>'+esc(c.label)+'</option>').join('') : '<option>[대상 찾기]를 눌러 주세요</option>'}</select><button data-x="ffind">대상 찾기</button></div>
  <div class="hint">WASD 이동 · Space/E 위 · Shift/Q 아래 · Ctrl 빠르게 · 벽 · 바닥 통과. 엉뚱한 게 움직이면 대상을 바꾸고 다시 켜세요. 3D(three.js) 게임용이에요.</div>
  <h3>🔫 모든 무기 · 아이템 갖기 <button data-x="uscan">찾기</button></h3>
  <div id="ul">${!up ? '<div class="hint">상점이 있는 게임(포레스트 스트라이크 등)에서 [찾기]를 누르세요.</div>'
    : up.pairs.length ? up.pairs.map(p=>'<div class="v"><code>'+esc(p.cat.name)+' ('+p.cat.ids.length+'개) → '+esc(p.own.name)+'</code><span style="font-size:11px">'+p.missing.length+'개 없음</span></div>').join('') + '<div class="row"><button class="g" data-x="unlock">전부 갖기</button></div>'
    : '<div class="hint">아이템 목록 '+up.cats.length+'개 · 가진 것 목록 '+up.owns.length+'개를 찾았지만 짝을 못 지었어요. 이 게임은 html 파일을 보내 주면 전용으로 만들어 줄게요.</div>'}</div>
  <h3>⏩ 게임 속도</h3><div class="row">${[0.25,0.5,1,2,3,5,10].map(n=>'<button data-sp="'+n+'" class="'+(n===speed?'on':'')+'">×'+n+'</button>').join('')}</div>
  <h3>🔎 게임 변수 (돈 · 레벨 · 체력 · 점프력 …) <button data-x="scan">찾기</button></h3>
  <div class="row"><input id="vf" placeholder="걸러보기 (예: money)" style="flex:1"></div>
  <div id="vars">${found.length ? '' : '<div class="hint">게임을 시작한 뒤 [찾기]를 누르세요.</div>'}</div>
  <div class="hint">"무한"을 켜면 그 값이 계속 유지돼요 (무한 돈 · 무한 체력 · 무한 탄약).</div>`;
}
function renderVars(){
  const box = sh.getElementById('vars'); if (!box || !found.length) return;
  const q = (sh.getElementById('vf').value || '').toLowerCase();
  box.innerHTML = '';
  found.filter(c=>!q || c.label.toLowerCase().includes(q)).slice(0, 80).forEach(c=>{
    const row = document.createElement('div'); row.className = 'v';
    let cur; try { cur = c.get(); } catch(e){ cur = '?'; }
    if (c.bool){
      row.innerHTML = '<code></code><button>' + (cur ? '켜짐' : '꺼짐') + '</button>';
      row.querySelector('code').textContent = c.label;
      row.querySelector('button').onclick = e=>{ const v = !c.get(); c.set(v); e.target.textContent = v ? '켜짐' : '꺼짐'; };
    } else {
      row.innerHTML = '<code></code><input type="number"><button>설정</button><label><input type="checkbox"> 무한</label>';
      row.querySelector('code').textContent = c.label;
      const inp = row.querySelector('input[type=number]'), cb = row.querySelector('input[type=checkbox]');
      inp.value = cur; cb.checked = frozen.has(c);
      row.querySelector('button').onclick = ()=>{ try { c.set(+inp.value); if (frozen.has(c)) frozen.set(c, +inp.value); toast(c.label + ' = ' + inp.value); } catch(e){ toast('못 바꿔요 (const)'); } };
      cb.onchange = ()=>{ if (cb.checked){ try { c.set(+inp.value); frozen.set(c, +inp.value); } catch(e){ cb.checked = false; toast('못 바꿔요'); } } else frozen.delete(c); };
    }
    box.appendChild(row);
  });
}

/* ================= 저장값 ================= */
function lsHTML(){
  return `<div class="row"><input id="lf" placeholder="검색 (coin, xp, level …)" style="flex:1"><button data-x="bk">백업 받기</button></div>
  <div class="hint">값을 바꾸고 💾 → 게임을 새로고침하면 적용돼요.</div><div id="lsl"></div><div class="row"><button class="b" data-x="reload">새로고침</button></div>`;
}
function renderLS(){
  const box = sh.getElementById('lsl'); if (!box) return;
  const q = (sh.getElementById('lf').value || '').toLowerCase(), ks = [];
  for (let i = 0; i < localStorage.length; i++){ const k = localStorage.key(i); if (!q || k.toLowerCase().includes(q)) ks.push(k); }
  box.innerHTML = '';
  ks.sort().slice(0, 120).forEach(k=>{
    const v = localStorage.getItem(k) || '', num = /^-?\d+(\.\d+)?$/.test(v);
    const row = document.createElement('div'); row.className = 'v';
    row.innerHTML = '<code></code><input class="t"><button>💾</button>' + (num ? '<button>MAX</button>' : '') + '<button class="r">✕</button>';
    row.querySelector('code').textContent = k;
    const inp = row.querySelector('input'); inp.value = v.length > 300 ? v.slice(0, 300) : v; if (v.length > 300) inp.disabled = true;
    const bs = row.querySelectorAll('button');
    bs[0].onclick = ()=>{ localStorage.setItem(k, inp.value); syncHub(); toast('저장: ' + k); };
    if (num) bs[1].onclick = ()=>{ inp.value = '99999999'; localStorage.setItem(k, '99999999'); syncHub(); toast('MAX: ' + k); };
    bs[bs.length - 1].onclick = ()=>{ if (confirm(k + ' 지울까요?')){ localStorage.removeItem(k); renderLS(); } };
    box.appendChild(row);
  });
}
ACT.bk = ()=>{ const o = {}; for (let i = 0; i < localStorage.length; i++){ const k = localStorage.key(i); o[k] = localStorage.getItem(k); }
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify(o, null, 1)], { type:'application/json' })); a.download = 'playhub-backup.json'; a.click(); };
ACT.reload = ()=> location.reload();
ACT.scan = ()=>{ scan(); renderVars(); toast(found.length + '개 찾음'); };
ACT.fly = flyToggle;
ACT.ffind = ()=>{ const n = findThree(); toast(n ? '대상 ' + n + '개 찾음' : '못 찾았어요 — 게임을 시작한 뒤 다시'); render(); };
ACT.uscan = ()=>{ scanUnlock(); render(); };
ACT.unlock = doUnlock;

/* ================= 그리기 ================= */
function render(){
  BD.innerHTML = tab === 'acc' ? accHTML() : tab === 'game' ? gameHTML() : lsHTML();
  if (tab === 'acc'){ sh.getElementById('lbCat').onchange = loadMine; loadMine(); }
  if (tab === 'game'){ renderVars(); sh.getElementById('vf').oninput = renderVars;
    sh.getElementById('fsp').oninput = e=>{ FLY.speed = +e.target.value; };
    sh.getElementById('ftg').onchange = e=>{ FLY.sel = +e.target.value; if (FLY.on){ const c = FLY.cands[FLY.sel]; if (c){ FLY.target = c.o; FLY.pos = curPos(c.o); FLY.vels = findVels(); } } }; }
  if (tab === 'ls'){ renderLS(); sh.getElementById('lf').oninput = renderLS; }
}
BD.addEventListener('click', e=>{
  const b = e.target.closest('button'); if (!b) return;
  if (b.dataset.sp){ setSpeed(+b.dataset.sp); BD.querySelectorAll('[data-sp]').forEach(x=>x.classList.toggle('on', x === b)); toast('속도 ×' + b.dataset.sp); return; }
  if (b.dataset.x && ACT[b.dataset.x]) ACT[b.dataset.x]();
});
render();
toast('어드민 켜짐 — 버튼을 다시 누르면 숨겨져요');
})();
