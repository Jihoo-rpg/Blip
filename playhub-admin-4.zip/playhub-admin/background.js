// 확장 아이콘(또는 ⌘⇧Y)을 누르면 지금 보고 있는 페이지 안에 어드민 창을 띄운다.
// world: 'MAIN' 이라서 그 페이지의 MP(multiplayer.js) · 게임 변수에 직접 손댈 수 있다.
chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.id || !/^https?:|^file:/.test(tab.url || '')) return;
  try {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', files: ['admin-panel.js'] });
  } catch (e) {
    chrome.action.setBadgeText({ tabId: tab.id, text: '!' });
    chrome.action.setTitle({ tabId: tab.id, title: '이 페이지에서는 못 열어요: ' + e.message });
  }
});
